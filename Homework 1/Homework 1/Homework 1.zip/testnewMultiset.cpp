#include "newMultiset.h"

int main()
{
	return 0;
}